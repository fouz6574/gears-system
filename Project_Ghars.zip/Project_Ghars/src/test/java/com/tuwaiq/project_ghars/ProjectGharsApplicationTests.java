package com.tuwaiq.project_ghars;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectGharsApplicationTests {

    @Test
    void contextLoads() {
    }

}

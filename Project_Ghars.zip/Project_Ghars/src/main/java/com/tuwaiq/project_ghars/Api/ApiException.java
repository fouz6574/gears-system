package com.tuwaiq.project_ghars.Api;

public class ApiException extends RuntimeException {
    public ApiException(String message) {
        super(message);
    }
}
